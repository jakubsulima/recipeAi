export const TIMEOUT = 10;
export const API_URL = "http://localhost:8080/";
