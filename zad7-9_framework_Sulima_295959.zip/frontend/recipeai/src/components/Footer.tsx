const Footer = () => {
  return <div className="flex fixed bottom-0 z-50">Footer</div>;
};

export default Footer;
