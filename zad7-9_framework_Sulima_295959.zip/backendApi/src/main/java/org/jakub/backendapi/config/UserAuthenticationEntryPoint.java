package org.jakub.backendapi.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jakub.backendapi.dto.ErrorDto;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import org.springframework.http.MediaType;

import javax.naming.AuthenticationException;
import java.io.IOException;

@Component
public class UserAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private static final ObjectMapper objectMapper = new ObjectMapper();


    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, org.springframework.security.core.AuthenticationException authException) throws IOException, ServletException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        ResponseCookie cookie = ResponseCookie.from("myCookie", "value")
        .httpOnly(true)
        .secure(true)
        .path("/")
        .sameSite("None")
        .build();

        response.setHeader(HttpHeaders.SET_COOKIE, cookie.toString());
        objectMapper.writeValue(response.getOutputStream(), new ErrorDto("Unauthorized path"));
    }
}
