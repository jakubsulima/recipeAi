package org.jakub.backendapi.entities;

public enum Role {
    USER,
    ADMIN
}

